# NATS

For more on NATS please visit NATS docs in GitHub:

<https://github.com/nats-io/nats.docs>

For more on NATS on k8s, please visit:

<https://github.com/nats-io/k8s>
